A Pen created at CodePen.io. You can find this one at https://codepen.io/leomarquine/pen/xGzMjZ.

 Animated gauge chart with dynamic color scale made with D3 js